/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        manzur: {
          primary: '#0669b3',
          secondary: '#368aca',
        },
      },
      screens: {
        'xs': '475px',
      },
    },
  },
  plugins: [],
}